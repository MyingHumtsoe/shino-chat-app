import React from "react";
import { Stack, Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import Chats from "./Chats";
import Conversation from "../../components/Conversation/Conversation";
import Contact from "../../components/Contact";

import { useSelector } from "react-redux";
import SharedMessages from "../../components/SharedMessages";

const GeneralApp = () => {
  const theme = useTheme();
  const { sidebar } = useSelector((store) => store.app);

  return (
    <Stack direction="row" sx={{ width: "100%", height: "100vh" }}>
      {/* Chats */}
      <Chats />
      {/* Conversation */}
      <Box
        sx={{
          height: "100vh",
          width: sidebar.open ? "calc(100vw - 740px)" : "calc(100vw - 420px)",
          backgroundColor:
            theme.palette.mode === "light"
              ? "#F0F5FA"
              : theme.palette.background.paper,
        }}
      >
        <Conversation />
      </Box>
      {/* Sidebar Content */}
      {sidebar.open &&
        (() => {
          switch (sidebar.type) {
            case "CONTACT":
              return <Contact />;

            case "STARRED":
              break;
            case "SHARED":
              return <SharedMessages />;

            default:
              break;
          }
        })()}
    </Stack>
  );
};

///export default GeneralApp;
