import { Stack, Box } from "@mui/material";
import React from "react";
import { useTheme } from "@mui/material/styles";
import Message from "./Message";
import Header from "./Header";
import Footer from "./Footer";

const Conversation = () => {
  const theme = useTheme(); // Correct usage of useTheme
  return (
    <Stack height="100%" maxHeight="100vh" width="auto" direction="column">
      <Header />
      <Box
        sx={{
          flexGrow: 1,
          maxHeight: "100%", // Correct capitalization: maxHeight instead of maxheight
          width: "100%",
          overflowY: "scroll",
          backgroundColor:
            theme.palette.mode === "light"
              ? "#fff"
              : theme.palette.background.default,
          boxShadow: "0px 0px 2px rgba(0,0,0,0.25)",
        }}
      >
        <Message menu={true} />
      </Box>
      <Footer />
    </Stack>
  );
};

export default Conversation;
