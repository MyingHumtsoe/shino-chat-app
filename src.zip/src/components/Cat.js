import React, { useState, useEffect } from "react";
import { Avatar } from "@mui/material";

const Cat = ({ showAvatar }) => {
  const [shouldRenderAvatar, setShouldRenderAvatar] = useState(false);

  useEffect(() => {
    if (showAvatar) {
      // Simulate delay or loading logic if needed
      const timer = setTimeout(() => {
        setShouldRenderAvatar(true);
      }, 100); // Delay can be adjusted

      return () => clearTimeout(timer);
    }
  }, [showAvatar]);

  return shouldRenderAvatar ? (
    <Avatar src="https://images.pexels.com/photos/846741/pexels-photo-846741.jpeg" />
  ) : null;
};

export default Cat;
