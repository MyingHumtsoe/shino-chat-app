import { Container, Stack } from "@mui/material";
import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import Logo from "../../assets/Images/bear.ico";

const MainLayout = () => {
  const isAuthenticated = true;
  if (!isAuthenticated) {
    return <Navigate to="/auth/login" />;
  }
  return (
    <>
      <Container sx={{ mt: 5 }} maxWidth="sm">
        <Stack spacing={5}>
          <Stack sx={{ with: "100" }} direction="column" alignItems="center">
            <img style={{ height: 60, width: 60 }} src={Logo} alt="logo" />
          </Stack>
        </Stack>
        {/* <div>Main Layout</div> */}

        <Outlet />
      </Container>
    </>
  );
};

export default MainLayout;
