import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { Box, Stack } from "@mui/material";

import SideBar from "./SideBar";

const isAuthenticated = true;
const DashboardLayout = () => {
  if (!isAuthenticated) {
    return <Navigate to="/auth/login" />;
  }
  return (
    <Stack direction="row" sx={{ height: "100vh", width: "100%" }}>
      {/*sidebar */}
      <SideBar />
      <Box sx={{ flex: 1, overflow: "auto" }}>
        <Outlet />
      </Box>
    </Stack>
  );
};

export default DashboardLayout;
